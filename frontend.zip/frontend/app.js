let provider;
let signer;
let contract;

const CONTRACT_ADDRESS = "0x5FbDB2315678afecb367f032d93F642f64180aa3";


async function connectWallet() {
    provider = new ethers.BrowserProvider(window.ethereum);
    signer = await provider.getSigner();

    document.getElementById("wallet").innerText = await signer.getAddress();

    await loadContract();
    await refreshUI();
}

async function loadContract() {
    const abi = await fetch("abi.json").then(r => r.json());
    contract = new ethers.Contract(CONTRACT_ADDRESS, abi, signer);
}

async function refreshUI() {
    const wallet = await signer.getAddress();
    const bal = await contract.balanceOf(wallet);

    document.getElementById("balance").innerText = ethers.formatEther(bal);

    const student = await contract.getStudentInfo(wallet);

    document.getElementById("whitelistStatus").innerText =
        student.isWhitelisted ? "Whitelisted" : "Not Whitelisted";

    document.getElementById("studentName").innerText = student.name;
    document.getElementById("studentId").innerText = student.studentId;
}

async function transferTokens() {
    const to = document.getElementById("transferTo").value;
    const amt = document.getElementById("transferAmount").value;

    await contract.transfer(to, ethers.parseEther(amt));
    await refreshUI();
}

async function mintTokens() {
    const to = document.getElementById("mintTo").value;
    const amt = document.getElementById("mintAmount").value;

    await contract.mint(to, ethers.parseEther(amt));
    await refreshUI();
}

document.getElementById("connectBtn").onclick = connectWallet;
